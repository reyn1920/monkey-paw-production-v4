#!/bin/zsh
rm -f reports/PANIC_SWITCH.true
echo "Panic switch OFF — publishing allowed."
