#!/bin/zsh
echo "panic" > reports/PANIC_SWITCH.true
echo "Panic switch ON — publishing disabled."
