# Monkey Paw Productions — Live Pack
Local-first, add-only, zero-cost. Fully automatic pipeline with manual approval gate before real publishing.

## Quick Start
```bash
cd monkey-paw-productions
zsh ./scripts/run_local.zsh
# in another terminal:
zsh ./scripts/live_test.zsh
# approve when ready:
zsh ./scripts/approve_publish.zsh
```
