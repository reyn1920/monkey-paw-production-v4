# service utilities for research/draft/repurpose/publish
