Project Doctor: diagnose → compare → separate (copy‑based).
Works on any repo; writes reports under ./reports.
