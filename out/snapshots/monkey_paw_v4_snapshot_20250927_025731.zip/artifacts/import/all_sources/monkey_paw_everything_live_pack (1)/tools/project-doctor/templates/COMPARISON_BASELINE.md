# Intended vs. Actual — Comparison

## Intended (Monkey Paw baseline)
- Research → Draft → Repurpose → Publish
- Local‑first with approval gate before any real publish
- SQLite or simple store; artifacts versioned under ./artifacts
- Endpoints: /api/health, /api/status, /api/research, /api/draft, /api/repurpose, /api/publish
- Feature flag: nocode_stack_enabled

## Actual (from latest diagnostics)
(Sections below are auto‑filled from diagnostic JSONs.)
