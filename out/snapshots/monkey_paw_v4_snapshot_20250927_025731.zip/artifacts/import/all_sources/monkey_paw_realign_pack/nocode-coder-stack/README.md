# No‑Code Coder Stack — Addon (separate project)

This holds the “no‑code coders” ecosystem as a separate addon. Keep it decoupled from the core.
- Lives at `~/Desktop/nocode-coder-stack` after running the separator script.
- Maintain its own README, prompts, and agents. Integrate via API boundaries when desired.

Zero‑cost, add‑only, and Rule‑1 friendly.
