# Monkey Paw Realign Pack

This pack helps you:
1) Separate the “no‑code coders” stack into its own addon project (copy‑based, no deletions).
2) Keep the Monkey Paw core focused on content automation.
3) Provide an API health endpoint and a features toggle to keep the addon disabled by default.

Start here:
- Read `PACK/ONE_PASTE_PROMPT.txt`.
- Place `scripts/` under `~/Desktop/monkey-paw/` and run the separator.
